/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define(
    "boardlist",
    {
      BO_CODE: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: "0",
      },
      BO_TITLE: {
        type: DataTypes.STRING(60),
        allowNull: true,
      },
      BO_HIT: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: "0",
      },
      BO_CREATION_DATE: {
        type: DataTypes.DATE,
        allowNull: true,
      },
      BO_COMMENT_COUNT: {
        type: DataTypes.BIGINT,
        allowNull: true,
      },
      BO_HEALTHSEE_COUNT: {
        type: DataTypes.BIGINT,
        allowNull: true,
      },
      BO_REPORT_COUNT: {
        type: DataTypes.BIGINT,
        allowNull: true,
      },
    },
    {
      tableName: "boardlist",
      timestamps: false,
    }
  );
};
