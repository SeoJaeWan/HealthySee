/* jshint indent: 2 */

module.exports = function (sequelize, DataTypes) {
  return sequelize.define(
    "b_healthysee",
    {
      BH_Code: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
      },
      BH_Push_NickName: {
        type: DataTypes.STRING(16),
        allowNull: false,
      },
      BH_Creation_Date: {
        type: DataTypes.DATE,
        allowNull: false,
      },
      Board_BO_Code: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        references: {
          model: "board",
          key: "BO_Code",
        },
      },
    },
    {
      tableName: "b_healthysee",
      timestamps: false,
    }
  );
};
